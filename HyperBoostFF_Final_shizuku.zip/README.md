# HyperBoost FF - Modified Project
Project updated with:
- SplashActivity and splash layout
- MainActivity (Compose scaffold placeholder)
- OptimizationManager (simulated actions, replace with Shizuku integration)
- activity_main.xml with buttons for core flows
- strings and colors updated for branding
- AndroidManifest updated to use SplashActivity as launcher

Build:
1. Open this folder in Android Studio.
2. Ensure Kotlin and Compose (or adjust MainActivity if not using Compose) settings match your project.
3. Replace simulated commands in OptimizationManager with real Shizuku calls if desired.
4. Place `leozito_logo.png` into `app/src/main/res/drawable/` (already included if provided).



## Shizuku integration added

- Dependency added to `app/build.gradle`:
  - `implementation "dev.rikka.shizuku:api:13.1.5"`
  - `implementation "dev.rikka.shizuku:provider:13.1.5"`

- Provider entry added to `AndroidManifest.xml`:
  - `rikka.shizuku.ShizukuProvider` with authorities `${applicationId}.shizuku`

- New helper files:
  - `ShizukuHelper.kt` — helpers to request permission and execute shell commands via `Shizuku.newProcess`.
  - `ResolutionValidator.kt` — parsing and validation logic for `wm size` outputs.
  - `OptimizationManager.kt` — backup/restore helpers (updated).

**Notes:** The project now contains real Shizuku API usage (request permission + newProcess). To test:
1. Install Shizuku app on the device and start it (via wireless debugging or ADB).
2. Open HyperBoost FF, press *Ativar permissões Shizuku* and allow permission in Shizuku.
3. Use *Iniciar Otimização* to run the sample resolution flow.

