package com.leozito.hyperboostff

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnActivate = findViewById<Button>(R.id.btnActivateShizuku)
        val btnStart = findViewById<Button>(R.id.btnStartOpt)
        val btnOpen = findViewById<Button>(R.id.btnOpenFF)

        btnActivate.setOnClickListener {
            // Check and request Shizuku permission
            if (ShizukuHelper.checkPermission(this)) {
                Toast.makeText(this, "Shizuku: permissão já concedida.", Toast.LENGTH_SHORT).show()
            } else {
                ShizukuHelper.requestPermission(this, 1)
            }
        }

        btnStart.setOnClickListener {
            // Run a resolution sample flow: detect, validate, backup, apply a safe change
            scope.launch {
                val current = withContext(Dispatchers.IO) { ShizukuHelper.execAndCollect("wm size") }
                if (current == null) {
                    Toast.makeText(this@MainActivity, "Não foi possível detectar resolução (Shizuku não disponível).", Toast.LENGTH_LONG).show()
                    return@launch
                }
                val parsed = ResolutionValidator.parseWmSizeOutput(current)
                if (parsed == null) {
                    Toast.makeText(this@MainActivity, "Saída de resolução inesperada: $current", Toast.LENGTH_LONG).show()
                    return@launch
                }
                val (w,h) = parsed
                val valid = ResolutionValidator.validateSafe(w,h)
                if (!valid.isValid) {
                    Toast.makeText(this@MainActivity, "Validação falhou: ${valid.reason}", Toast.LENGTH_LONG).show()
                    return@launch
                }
                // backup
                OptimizationManager.backupResolution(this@MainActivity, w, h)
                // apply scaled resolution example: reduce by 0.9x for safety
                val newW = (w * 0.9).toInt().coerceAtLeast(320)
                val newH = (h * 0.9).toInt().coerceAtLeast(320)
                val cmd = "wm size ${newW}x${newH}"
                val ok = withContext(Dispatchers.IO) { ShizukuHelper.execCommand(cmd) }
                if (ok) {
                    Toast.makeText(this@MainActivity, "Resolução aplicada: ${newW}x${newH}", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@MainActivity, "Falha ao aplicar resolução.", Toast.LENGTH_LONG).show()
                }
            }
        }

        btnOpen.setOnClickListener {
            val pm = packageManager
            val intent = pm.getLaunchIntentForPackage("com.dts.freefireth")
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Free Fire não encontrado.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
