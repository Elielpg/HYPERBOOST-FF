package com.leozito.hyperboostff

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import moe.shizuku.api.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuHelper {
    private const val TAG = "ShizukuHelper"

    fun checkPermission(context: Context): Boolean {
        try {
            if (Shizuku.isPreV11()) return false
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            Log.e(TAG, "checkPermission error", e)
            return false
        }
    }

    fun requestPermission(activity: Activity, requestCode: Int) {
        try {
            Shizuku.addRequestPermissionResultListener { code, granted ->
                if (code == requestCode) {
                    // no-op here; activity may check ShizukuHelper.checkPermission()
                }
            }
            Shizuku.requestPermission(requestCode)
        } catch (e: Exception) {
            Log.e(TAG, "requestPermission error", e)
        }
    }

    /**
     * Execute command using Shizuku.newProcess() and return whether exitCode == 0
     */
    fun execCommand(command: String): Boolean {
        try {
            if (!checkPermissionInternal()) return false
            val cmd = arrayOf("sh", "-c", command)
            val process = Shizuku.newProcess(cmd, null, null)
            val exit = process.waitFor()
            return exit == 0
        } catch (e: Exception) {
            Log.e(TAG, "execCommand error: " + e.message, e)
            return false
        }
    }

    /**
     * Execute command and collect stdout as String (or null on failure)
     */
    fun execAndCollect(command: String): String? {
        try {
            if (!checkPermissionInternal()) return null
            val cmd = arrayOf("sh", "-c", command)
            val process = Shizuku.newProcess(cmd, null, null)
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val sb = StringBuilder()
            var line: String? = reader.readLine()
            while (line != null) {
                sb.append(line).append("\n")
                line = reader.readLine()
            }
            process.waitFor()
            return sb.toString().trim()
        } catch (e: Exception) {
            Log.e(TAG, "execAndCollect error", e)
            return null
        }
    }

    private fun checkPermissionInternal(): Boolean {
        return try {
            !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }
}
