package com.leozito.hyperboostff

data class ValidationResult(val isValid: Boolean, val reason: String = "")

object ResolutionValidator {
    private const val MIN_DIM = 320
    private const val MAX_RATIO_DIFF_PERCENT = 20.0
    private const val MAX_SCALE_UP = 3.0
    private const val MIN_SCALE = 0.25

    /**
     * Parse output of `wm size`, example: 'Physical size: 1080x2400' or 'Physical size: 1080x2400\n'
     */
    fun parseWmSizeOutput(output: String): Pair<Int,Int>? {
        val regex = Regex("(\d{2,5})x(\d{2,5})")
        val match = regex.find(output)
        return if (match != null) {
            val w = match.groupValues[1].toInt()
            val h = match.groupValues[2].toInt()
            // normalize so smaller first as per your validation rules (width, height -> width<=height)
            if (w <= h) Pair(w,h) else Pair(h,w)
        } else null
    }

    fun validateSafe(width: Int, height: Int): ValidationResult {
        val w = minOf(width, height)
        val h = maxOf(width, height)
        if (w < MIN_DIM || h < MIN_DIM) return ValidationResult(false, "Dimensão mínima não atingida: ${w}x${h}")
        val ratio = w.toDouble() / h.toDouble()
        // compare to standard ratio (use current as baseline)
        // For safety we just check that flipping would not produce extreme stretch
        val diffPercent = (1.0 - ratio) * 100.0
        if (diffPercent > MAX_RATIO_DIFF_PERCENT) return ValidationResult(false, "Diferença de proporção maior que ${MAX_RATIO_DIFF_PERCENT}%")
        // scale checks are contextual; we accept current as baseline
        return ValidationResult(true)
    }
}
