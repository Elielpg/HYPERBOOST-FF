package com.leozito.hyperboostff

import android.content.Context
import android.content.SharedPreferences
import android.util.Log

object OptimizationManager {
    private const val TAG = "OptimizationManager"
    private const val PREFS = "hyperboost_prefs"
    private const val KEY_W = "backup_w"
    private const val KEY_H = "backup_h"

    fun backupResolution(context: Context, width: Int, height: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putInt(KEY_W, width).putInt(KEY_H, height).apply()
        Log.i(TAG, "Backup resolution saved ${'$'}width x ${'$'}height")
    }

    fun restoreResolution(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val w = prefs.getInt(KEY_W, -1)
        val h = prefs.getInt(KEY_H, -1)
        if (w <= 0 || h <= 0) return false
        val cmd = "wm size ${'$'}w x ${'$'}h".replace(" ", "")
        return ShizukuHelper.execCommand(cmd)
    }

    // Other optimization stubs kept for later
}
