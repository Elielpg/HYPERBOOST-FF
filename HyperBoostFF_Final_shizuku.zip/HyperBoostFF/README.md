# HyperBoostFF — Projeto Final (pronto para build)

Versão: HyperBoost FF — Tema Dark Neon Azul (T1), Perfil padrão: Alto Desempenho, Idioma: pt-BR.

## Conteúdo
- Painel Web (app/assets/painel.html) — UI Dark Neon Azul T1.
- MainActivity.kt (WebView + interface JS <-> Android).
- OptimizerService.kt (executor de comandos; suporta perfis via assets/profiles.json).
- Perfis em app/src/main/assets/profiles.json (balanced, performance, battery, competitive, alto_desempenho_default).
- strings.xml (pt-BR) em app/src/main/res/values/strings.xml.
- ic_launcher (vector placeholder) em mipmap-anydpi-v26.
- app/build.gradle pronto para compilar (applicationId: com.hyperboost.ff).
- README com instruções de build no PC e Termux.

## Build recomendado (PC - Android Studio)
1. Extraia `HyperBoostFF_Final.zip` e abra a pasta `HyperBoostFF` no Android Studio.
2. Instale SDKs caso o Android Studio peça (compileSdk 33, build-tools 33).
3. Aguarde o Gradle sincronizar.
4. `Build -> Build Bundle(s) / APK(s) -> Build APK(s)`
5. APK em `app/build/outputs/apk/debug/app-debug.apk`

## Build alternativo (Termux - avançado)
1. Configure Termux com Java 17 em PATH, Android SDK command-line tools, e Gradle.
2. Copie o projeto para `/storage/emulated/0/Download/HyperBoostFF`.
3. No Termux, rode `./gradlew assembleDebug` ou `gradle assembleDebug`.
4. Se ocorrer erro, siga as mensagens e ajuste SDK/Gradle conforme instruções no arquivo.

## Observações importantes
- Ajustes profundos de sistema (wm, setprop, density) exigem **ADB (depuração)** ou root. O app guia o usuário para habilitar ADB/depuração Wi‑Fi.
- O projeto está configurado para gerar APK universal (armeabi-v7a + arm64-v8a) via Gradle se você habilitar os splits em build.gradle.
- Para publicar no Play Store, gere um build release assinado com sua keystore.

## Posso te ajudar com:
- Gerar APK debug e orientar na instalação.
- Gerar release assinado (se você fornecer keystore e senha).
- Melhorar ícone/art.

