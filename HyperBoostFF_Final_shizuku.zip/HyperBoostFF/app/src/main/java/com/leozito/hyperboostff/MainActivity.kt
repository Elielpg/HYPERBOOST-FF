package com.leozito.hyperboostff

import android.annotation.SuppressLint
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        val ws: WebSettings = webView.settings
        ws.javaScriptEnabled = true
        ws.allowFileAccess = true
        ws.domStorageEnabled = true
        webView.webViewClient = WebViewClient()

        webView.addJavascriptInterface(WebAppInterface(), "Android")

        // Load local asset
        webView.loadUrl("file:///android_asset/painel.html")
    }

    inner class WebAppInterface {
        @JavascriptInterface
        fun getDeviceInfo(): String {
            // Build a JSON with basic device info & recommendations
            val obj = JSONObject()
            obj.put("model", Build.MODEL)
            obj.put("manufacturer", Build.MANUFACTURER)
            obj.put("sdk", Build.VERSION.SDK_INT)
            // Basic heuristic recommendations (can be improved)
            if (Build.VERSION.SDK_INT >= 31) {
                obj.put("recommendedResolution", "1080x2400")
                obj.put("recommendedFPS", 90)
                obj.put("recommendedRender", "high")
            } else if (Build.VERSION.SDK_INT >= 29) {
                obj.put("recommendedResolution", "1080x2400")
                obj.put("recommendedFPS", 60)
                obj.put("recommendedRender", "standard")
            } else {
                obj.put("recommendedResolution", "720x1600")
                obj.put("recommendedFPS", 30)
                obj.put("recommendedRender", "conservative")
            }
            return obj.toString()
        }

        @JavascriptInterface
        fun execCommand(cmd: String) {
            // Convert web commands into intents for the service
            val intent = Intent(this@MainActivity, OptimizerService::class.java)
            intent.putExtra("cmd", cmd)
            startService(intent)
        }
    }
}
